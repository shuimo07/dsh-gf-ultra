import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { VoiceInjected } from '../contract.ts';
/** Full props: framework runtime share + `voice` locale seat + injected face. */
export type CompanionWindowProps = PropsRuntime<'conversation.input.left'> & PropsLocale<'voice'> & VoiceInjected;
/**
 * @param props - framework runtime + locale + injected speaker face.
 */
export declare const CompanionWindow: import("react").MemoExoticComponent<({ speaker, companion }: CompanionWindowProps) => import("react").JSX.Element | null>;
//# sourceMappingURL=companion.d.ts.map