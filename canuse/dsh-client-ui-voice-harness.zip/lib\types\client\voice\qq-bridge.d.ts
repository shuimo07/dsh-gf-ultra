import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { VoiceInjected } from '../contract.ts';
/** Full props: framework runtime share + `voice` locale seat + injected face. */
export type QQBridgeProps = PropsRuntime<'conversation.input.left'> & PropsLocale<'voice'> & VoiceInjected;
/**
 * @param props - framework runtime + locale + injected sendText.
 */
export declare const QQBridge: import("react").MemoExoticComponent<({ useSession, sendText }: QQBridgeProps) => null>;
//# sourceMappingURL=qq-bridge.d.ts.map