import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { VoiceInjected } from './contract.ts';
/** Full toggle props: framework runtime share + `voice` locale seat + injected face. */
export type BusyToggleProps = PropsRuntime<'conversation.input.left'> & PropsLocale<'voice'> & VoiceInjected;
/**
 * @param props - framework runtime + locale + injected sendText (delivery mode).
 */
export declare const BusyToggle: import("react").MemoExoticComponent<({ t }: BusyToggleProps) => import("react").JSX.Element>;
//# sourceMappingURL=BusyToggle.d.ts.map