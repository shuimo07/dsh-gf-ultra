/**
 * CompanionController: shared visibility state for the companion window.
 *
 * Created once in apply and injected to both the CompanionWindow (renders the
 * overlay) and the CompanionToggle (flips it), so the toggle takes effect
 * immediately without a store. Persisted to `s2s.voice.companion`.
 */
export declare class CompanionController {
    private listeners;
    private value;
    constructor();
    get visible(): boolean;
    set visible(next: boolean);
    /** Subscribe to visibility changes; returns the unsubscribe function. */
    subscribe(listener: () => void): () => void;
}
//# sourceMappingURL=companion-controller.d.ts.map