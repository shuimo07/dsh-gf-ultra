import type { VadStream } from '../bridge.ts';
export interface MicRecorderOptions {
    minSilenceMs?: number;
    maxUtteranceMs?: number;
    rmsThreshold?: number;
    /** Streamed to the bridge's silero VAD while a reply is playing; its
     *  `speech_start` is the barge-in trigger. When absent, the recorder falls
     *  back to the RMS heuristics below (interruptThreshold / hold / confirm). */
    vad?: VadStream;
    /** RMS threshold for barge-in detection during playback (fallback path). */
    interruptThreshold?: number;
    /** Sustained above-threshold time (ms) before a barge-in fires (fallback). */
    interruptHoldMs?: number;
    /** After a barge-in fires, keep requiring the signal for this long before
     *  accumulating — a false alarm never becomes an utterance (fallback). */
    interruptConfirmMs?: number;
    /** Noise gate threshold in dBFS (0 or undefined = disabled). Quiet ambient
     *  audio below this level is faded out of the SENT mic stream — mirrors the
     *  original project's worklet gate (the attack/hold/release envelope
     *  already lives in the embedded worklet; this just arms it). */
    noiseGateDb?: number;
    /** Called once when speech is detected while a reply is playing (barge-in);
     *  the recorder then switches back to normal accumulation so the user's
     *  ongoing speech becomes the next utterance. */
    onSpeechInterrupt?: () => void;
    /** Called once with the complete silence-endpointed utterance (PCM16). */
    onUtterance: (pcm16: ArrayBuffer) => void;
}
export declare class MicRecorder {
    private readonly opts;
    private ctx;
    private stream;
    private source;
    private node;
    private chunks;
    private chunkBytes;
    private speaking;
    private lastVoiceAt;
    private maxTimer;
    private released;
    private paused;
    private interruptMode;
    private interruptArmed;
    private interruptHoldStart;
    private confirmArmed;
    private confirmStart;
    constructor(opts: MicRecorderOptions);
    get active(): boolean;
    /**
     * Pause/resume capture. While paused, incoming chunks and levels are
     * dropped (nothing accumulates, no endpointing fires). Used sparingly —
     * during playback we use {@link setInterruptMode} instead so barge-in
     * detection keeps running.
     */
    setPaused(paused: boolean): void;
    /**
     * Barge-in listening mode (during reply playback): chunks are streamed to
     * the bridge's silero VAD (never accumulated), which fires `speech_start`
     * only for a REAL human voice — TTS echo / music / ambient noise cannot
     * trip it. On `speech_start` the recorder leaves interrupt mode and the
     * user's ongoing speech accumulates normally.
     */
    setInterruptMode(enabled: boolean): void;
    /** Bridge VAD heard a real voice: stop the reply and accumulate the user's
     *  ongoing speech. (silero's speech_start is already the confirmation — no
     *  RMS hold/confirm heuristics needed on this path.) */
    private onVadSpeechStart;
    private resetBuffers;
    /** Acquire the mic and start the capture worklet. */
    start(): Promise<void>;
    /** Stop capture and release the mic / AudioContext. */
    stop(): void;
    private onLevel;
    private onChunk;
    private armMaxTimer;
    private flush;
    private concatChunks;
}
//# sourceMappingURL=recorder.d.ts.map