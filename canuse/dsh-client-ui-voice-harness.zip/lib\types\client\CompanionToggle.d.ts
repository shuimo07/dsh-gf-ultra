import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { VoiceInjected } from './contract.ts';
/** Full toggle props: framework runtime share + `voice` locale seat + injected face. */
export type CompanionToggleProps = PropsRuntime<'conversation.input.left'> & PropsLocale<'voice'> & VoiceInjected;
/**
 * @param props - framework runtime + locale + injected companion controller.
 */
export declare const CompanionToggle: import("react").MemoExoticComponent<({ t, companion }: CompanionToggleProps) => import("react").JSX.Element>;
//# sourceMappingURL=CompanionToggle.d.ts.map