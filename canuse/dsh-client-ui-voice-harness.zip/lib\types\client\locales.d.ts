/** `voice` namespace dictionaries. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'mic.title': string;
    'mic.listening': string;
    'mic.transcribing': string;
    'mic.error': string;
    'toggle.onHint': string;
    'toggle.offHint': string;
    'companion.onHint': string;
    'companion.offHint': string;
    'interrupt.onHint': string;
    'interrupt.offHint': string;
    'qqpush.onHint': string;
    'qqpush.offHint': string;
};
/** The voice namespace key union. */
export type VoiceKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    'mic.title': string;
    'mic.listening': string;
    'mic.transcribing': string;
    'mic.error': string;
    'toggle.onHint': string;
    'toggle.offHint': string;
    'companion.onHint': string;
    'companion.offHint': string;
    'interrupt.onHint': string;
    'interrupt.offHint': string;
    'qqpush.onHint': string;
    'qqpush.offHint': string;
};
//# sourceMappingURL=locales.d.ts.map