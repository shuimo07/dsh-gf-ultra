import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { VoiceInjected } from '../contract.ts';
/** Full props: framework runtime share + `voice` locale seat + injected face. */
export type ReplySpeakerMountProps = PropsRuntime<'conversation.input.left'> & PropsLocale<'voice'> & VoiceInjected;
/**
 * @param props - framework runtime + locale + injected speaker/abort face.
 */
export declare const ReplySpeakerMount: import("react").MemoExoticComponent<({ useSession, speaker, _registerTtsAbort, _registerInterruptHandler, }: ReplySpeakerMountProps) => null>;
//# sourceMappingURL=reply-listener.d.ts.map