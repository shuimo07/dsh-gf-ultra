/**
 * Clean assistant reply text for TTS reading.
 *
 * The reply body is markdown (headings, emphasis, lists, inline code, fenced
 * code blocks — including ```dsh-ui fences with JSON) plus URLs. Reading it
 * verbatim is noisy and can generate minutes of audio. This strips the
 * decorations, collapses whitespace, and caps the length at a sentence
 * boundary so a reading stays short and audible.
 */
/**
 * @param text - raw assistant markdown text.
 * @param maxChars - soft cap; truncation lands on a Chinese/English sentence
 *   boundary when one exists past the half-way point.
 * @returns clean, single-line, capped text ('' when nothing remains).
 */
export declare function cleanReplyText(text: string, maxChars?: number): string;
//# sourceMappingURL=clean.d.ts.map