/**
 * Bridge HTTP client: talks to the local voice-bridge service
 * (http://127.0.0.1:8765 by default, overridable via localStorage
 * `s2s.voice.bridge`).
 */
/** Resolve the bridge base URL (localStorage override wins). */
export declare function bridgeBase(): string;
/** Speech to text: raw 16 kHz mono PCM16 -> { text, language }. */
export declare function stt(pcm16: ArrayBuffer): Promise<{
    text: string;
    language?: string;
}>;
/** Text to speech: { text } -> 16 kHz mono PCM16 WAV bytes. */
export declare function tts(text: string, signal?: AbortSignal): Promise<ArrayBuffer>;
/**
 * Streaming silero VAD client for barge-in detection (the server-side VAD of
 * the original speech-to-speech project). While a reply is playing the mic
 * recorder pushes PCM16 chunks here; the bridge replies
 * `{ event: 'speech_start' }` only when a REAL human voice is detected — TTS
 * echo / music / ambient noise never trip it.
 */
export declare class VadStream {
    private ws;
    private buffered;
    private closed;
    private connected;
    /** Whether the VAD socket is actually connected. The recorder falls back to
     *  RMS heuristics while this is false (e.g. an old bridge without /api/vad). */
    get available(): boolean;
    /**
     * @param onSpeechStart - fired once when silero VAD hears speech.
     */
    open(onSpeechStart: () => void): void;
    /** Push one 16 kHz PCM16 chunk (no-op while the socket is down). */
    send(pcm16: ArrayBuffer): void;
    close(): void;
}
//# sourceMappingURL=bridge.d.ts.map