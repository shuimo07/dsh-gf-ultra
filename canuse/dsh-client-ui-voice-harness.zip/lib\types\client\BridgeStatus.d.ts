import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { VoiceInjected } from './contract.ts';
/** Full props: framework runtime share + `voice` locale seat + injected face. */
export type BridgeStatusProps = PropsRuntime<'conversation.input.left'> & PropsLocale<'voice'> & VoiceInjected;
/**
 * @param props - framework runtime + locale seats.
 */
export declare const BridgeStatus: import("react").MemoExoticComponent<(_props: BridgeStatusProps) => import("react").JSX.Element | null>;
//# sourceMappingURL=BridgeStatus.d.ts.map