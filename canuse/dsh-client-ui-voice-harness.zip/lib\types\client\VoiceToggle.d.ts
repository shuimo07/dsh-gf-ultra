import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { VoiceInjected } from './contract.ts';
/** Full toggle props: framework runtime share + `voice` locale seat + injected face. */
export type VoiceToggleProps = PropsRuntime<'conversation.input.left'> & PropsLocale<'voice'> & VoiceInjected;
/**
 * @param props - framework runtime + locale + injected speaker (interrupt).
 */
export declare const VoiceToggle: import("react").MemoExoticComponent<({ t, speaker, abortTts }: VoiceToggleProps) => import("react").JSX.Element>;
//# sourceMappingURL=VoiceToggle.d.ts.map