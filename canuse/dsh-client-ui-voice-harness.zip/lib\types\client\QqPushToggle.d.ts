import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { VoiceInjected } from './contract.ts';
export declare function readQqPush(): boolean;
/** Full toggle props: framework runtime share + `voice` locale seat + injected face. */
export type QqPushToggleProps = PropsRuntime<'conversation.input.left'> & PropsLocale<'voice'> & VoiceInjected;
/**
 * @param props - framework runtime + locale seats.
 */
export declare const QqPushToggle: import("react").MemoExoticComponent<({ t }: QqPushToggleProps) => import("react").JSX.Element>;
//# sourceMappingURL=QqPushToggle.d.ts.map