/**
 * Sentence splitting for streaming TTS (mirrors the original backend's
 * LMOutputProcessor: the reply is spoken sentence-by-sentence, so synthesis
 * pipelines with playback instead of waiting for the whole text).
 *
 * Chinese/English terminal punctuation: 。！？!?… (plus a closing quote/bracket
 * immediately after the terminator is absorbed into the sentence). The
 * trailing unterminated chunk is returned separately as `partial` — it is not
 * spoken until a terminator completes it.
 */
export interface SentenceSplit {
    /** Complete sentences, each ending with a terminator (trimmed). */
    sentences: string[];
    /** The trailing chunk without a terminator, or null when the text ends on a boundary. */
    partial: string | null;
}
/** Split text into complete sentences + a trailing partial chunk. */
export declare function splitSentences(text: string): SentenceSplit;
//# sourceMappingURL=sentences.d.ts.map