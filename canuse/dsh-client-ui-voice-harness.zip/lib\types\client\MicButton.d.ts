import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { VoiceInjected } from './contract.ts';
/** Full mic-control props: framework runtime share + `voice` locale seat + injected sendText. */
export type MicButtonProps = PropsRuntime<'conversation.input.left'> & PropsLocale<'voice'> & VoiceInjected;
/**
 * @param props - framework runtime + locale seats + injected sendText/speaker.
 */
export declare const MicButton: import("react").MemoExoticComponent<({ t, sendText, speaker, interruptReply }: MicButtonProps) => import("react").JSX.Element>;
//# sourceMappingURL=MicButton.d.ts.map