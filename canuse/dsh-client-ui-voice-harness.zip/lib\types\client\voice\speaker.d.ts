/**
 * ReplySpeaker: plays synthesized reply WAVs through an AudioContext as a
 * FIFO queue (sentence streaming). `speak()` enqueues; the drain plays one
 * clip at a time and `onended` advances to the next, so sentence N+1 starts
 * the moment N finishes (gaps between clips are tiny). `speaking` stays true
 * while anything is queued or playing, so the companion window and the mic
 * echo-guard follow the whole reply, not individual clips.
 *
 * Interruption: `stop()` halts the current clip and clears the queue; a
 * generation counter discards clips that were queued but not yet started.
 */
export declare class ReplySpeaker {
    private ctx;
    private queue;
    private playing;
    private drainRunning;
    private gen;
    private disposed;
    private listeners;
    /** True while a reply is being read (playing or waiting in the queue). */
    get speaking(): boolean;
    /** Subscribe to speaking-state changes; returns the unsubscribe function. */
    subscribe(listener: () => void): () => void;
    private emit;
    /** Enqueue one clip for playback (order preserved; plays after earlier clips). */
    speak(wav: ArrayBuffer): void;
    private drain;
    private playOne;
    /** Stop the current clip immediately and clear the queued ones. */
    stop(): void;
    /** Release the AudioContext (plugin teardown). */
    dispose(): void;
}
//# sourceMappingURL=speaker.d.ts.map